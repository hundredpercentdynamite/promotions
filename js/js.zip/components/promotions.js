import styled from "styled-components";

const PromoHeading = styled.h2`
    font-size: 24px;
    font-weight: 400;
`;

const ItemCountStyled = styled.span`
    
`;

const PromoHeadingContainer = styled.div`
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
`;

const SortingRadioButton = styled.div`
    display: inline-block;
    cursor: pointer;
    box-sizing: border-box;
    ${props => props.isRadioActive && 'border-bottom: 1px solid #03b4ee;'}
`;

class SortRadio extends React.Component {
    constructor(props) {
        super(props);
        this.toggleRadio = this.toggleRadio.bind(this);
        this.updateState = this.updateState.bind(this);
        this.state = {
            isRadioActive: !!props.default
        };
    }


    toggleRadio() {
        this.updateState({isRadioActive: !this.state.isRadioActive});
        console.log("isRadioActive", this.state.isRadioActive);
    }

    updateState(obj) {
        this.setState(obj);
    }

    render() {
        return (
            <SortingRadioButton isRadioActive={this.state.isRadioActive} onClick={this.toggleRadio} >{this.props.content}</SortingRadioButton>
        )
    }
}

class SortingContainer extends React.Component {
    constructor() {
        super();
    }

    render() {
        const {isRadioActive} = this.props;
        return(
            <div>
                <SortRadio isRadioActive={isRadioActive} content="Все акции" default={true}/>
                <SortRadio isRadioActive={isRadioActive} content="Подарок с покупкой"/>
                <SortRadio isRadioActive={isRadioActive} content="Клиентские дни"/>
            </div>
        )
    }
}


export class Promotions extends React.Component {
    render () {
        return (
            <div>
                <PromoHeadingContainer>
                    <PromoHeading>
                        Акции
                    </PromoHeading>
                    <ItemCountStyled>Найдено 13</ItemCountStyled>
                </PromoHeadingContainer>
                <SortingContainer/>
            </div>
        );
    }
}
