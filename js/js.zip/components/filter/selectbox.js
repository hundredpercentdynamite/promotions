// Компонент сортировки в виде select box
export class Sort extends Component {

    constructor(props) {
        super(props);
        let currentSort = props.sorts.filter(sortItem => sortItem.selected);

        this.state = {
            showSort: false,
            currentSort: {...currentSort[0]}
        }
    }

    sortToggle() {
        this.setState({
            showSort: !this.state.showSort
        });
        this.div.classList.toggle('active');
    }

    clickSortItem(event) {
        this.setState({
            currentSort: {...event.target.dataset},
            showSort: false
        });
        this.div.classList.remove('active');
        window.utils.sort = event.target.dataset.code;
        this.props.onChangeSortHandler(event.target.dataset.code);
    }

    render() {
        let {sorts} = this.props;
        let options = sorts.map((sortItem, i) => <li key={i}
                                                     data-code={sortItem.code}
                                                     data-name={sortItem.name}
                                                     onClick={this.clickSortItem.bind(this)}>
                                                     {sortItem.name}
                                                  </li>);
        return (
            <div className="sort">
                <div className="current-name"
                     ref={div => this.div = div}
                     onClick={this.sortToggle.bind(this)}>
                        {this.state.currentSort.name}
                </div>
                {this.state.showSort ? <ul className="options animated fadeInUp">{options}</ul> : null}
            </div>
        );
    }
}