import React from 'react';
import ReactDOM from 'react-dom';
import Rx from 'rxjs';
const R = require('ramda');


window.React = React;
window.ReactDOM = ReactDOM;
window.Rx = Rx;
window.R = R;
